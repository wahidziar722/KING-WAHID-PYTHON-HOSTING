import os
from pathlib import Path
from flask import Flask
from flask_wtf.csrf import CSRFProtect

BASE_DIR = Path(__file__).resolve().parent.parent

def create_app():
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", "dev-only-change-this-before-deploying"),
        MAX_CONTENT_LENGTH=10 * 1024 * 1024,
        PROJECTS_DIR=BASE_DIR / "data" / "users",
        DATABASE=BASE_DIR / "data" / "hosting.sqlite3",
        RUNNER_IMAGE=os.environ.get("RUNNER_IMAGE", "wahid-python-runner:latest"),
        ADMIN_EMAIL=os.environ.get("ADMIN_EMAIL", "").strip().lower(),
    )
    app.config["PROJECTS_DIR"].mkdir(parents=True, exist_ok=True)
    app.config["DATABASE"].parent.mkdir(parents=True, exist_ok=True)
    CSRFProtect(app)

    from .db import init_db
    with app.app_context():
        init_db()

    from .routes import bp
    app.register_blueprint(bp)
    return app
