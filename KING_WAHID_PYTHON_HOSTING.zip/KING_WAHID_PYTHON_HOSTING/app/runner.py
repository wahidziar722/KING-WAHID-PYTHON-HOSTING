import re, subprocess
from pathlib import Path

NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,40}$")

def container_name(user_id, project):
    return f"whp-u{int(user_id)}-{project}".lower()

def docker(args, timeout=30):
    return subprocess.run(["docker", *args], capture_output=True, text=True, timeout=timeout)

def build_runner(image):
    return docker(["build", "-t", image, "."], timeout=300)

def start_project(user_id, project, project_dir, image):
    if not NAME_RE.fullmatch(project):
        return False, "Invalid project name."
    folder = Path(project_dir)
    entry = folder / "main.py"
    if not entry.is_file():
        candidates = sorted(folder.glob("*.py"))
        if not candidates:
            return False, "No Python file found. Add main.py or another .py file."
        entry = candidates[0]
    cname = container_name(user_id, project)
    old = docker(["rm", "-f", cname])
    cmd = [
        "run", "-d", "--name", cname, "--init",
        "--network", "none",
        "--memory", "256m", "--memory-swap", "256m",
        "--cpus", "0.50", "--pids-limit", "64",
        "--read-only", "--tmpfs", "/tmp:rw,noexec,nosuid,size=32m",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
        "--user", "10001:10001",
        "-v", f"{folder.resolve()}:/workspace:ro",
        "-w", "/workspace",
        image, "python", "-u", f"/workspace/{entry.name}"
    ]
    result = docker(cmd, timeout=60)
    if result.returncode:
        return False, (result.stderr or result.stdout)[-1200:]
    return True, f"Container started: {result.stdout.strip()[:12]}"

def stop_project(user_id, project):
    result = docker(["rm", "-f", container_name(user_id, project)])
    if result.returncode and "No such container" in result.stderr:
        return False, "Project is not running."
    if result.returncode:
        return False, result.stderr[-800:]
    return True, "Project stopped."

def project_status(user_id, project):
    result = docker(["inspect", "-f", "{{.State.Status}}", container_name(user_id, project)])
    return result.stdout.strip() if result.returncode == 0 else "stopped"

def project_logs(user_id, project):
    result = docker(["logs", "--tail", "300", container_name(user_id, project)], timeout=20)
    return (result.stdout + result.stderr)[-30000:] or "No logs yet."
