import os, re, shutil, sqlite3, zipfile
from pathlib import Path, PurePosixPath
from flask import Blueprint, current_app, render_template, request, redirect, url_for, flash, session, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from .db import get_db
from .runner import start_project, stop_project, project_status, project_logs

bp = Blueprint("main", __name__)
NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,40}$")

def logged_in():
    return bool(session.get("uid"))

def login_required():
    if not logged_in():
        return redirect(url_for("main.login"))
    return None

def user_root():
    p = Path(current_app.config["PROJECTS_DIR"]) / str(session["uid"])
    p.mkdir(parents=True, exist_ok=True)
    return p

def safe_name(value):
    value = secure_filename(value or "")
    return value if NAME_RE.fullmatch(value) else None

def owned_project(name):
    name = safe_name(name)
    if not name:
        abort(404)
    p = user_root() / name
    if not p.is_dir():
        abort(404)
    return p

@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if len(email) > 254 or "@" not in email or len(password) < 10:
            flash("Enter a valid email and password with at least 10 characters.")
            return render_template("auth.html", mode="register")
        role = "admin" if email == current_app.config["ADMIN_EMAIL"] and current_app.config["ADMIN_EMAIL"] else "user"
        try:
            get_db().execute("INSERT INTO users(email,password_hash,role) VALUES(?,?,?)",
                             (email, generate_password_hash(password), role))
            get_db().commit()
        except sqlite3.IntegrityError:
            flash("That email is already registered.")
            return render_template("auth.html", mode="register")
        user = get_db().execute("SELECT id,role FROM users WHERE email=?", (email,)).fetchone()
        session.clear()
        session.update(uid=user["id"], role=user["role"], email=email)
        return redirect(url_for("main.index"))
    return render_template("auth.html", mode="register")

@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        row = get_db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if row and check_password_hash(row["password_hash"], request.form.get("password", "")):
            session.clear()
            session.update(uid=row["id"], role=row["role"], email=row["email"])
            return redirect(url_for("main.index"))
        flash("Incorrect email or password.")
    return render_template("auth.html", mode="login")

@bp.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("main.login"))

@bp.get("/")
def index():
    if not logged_in():
        return redirect(url_for("main.login"))
    projects = []
    for p in sorted(user_root().iterdir()):
        if p.is_dir():
            projects.append({"name": p.name, "status": project_status(session["uid"], p.name)})
    running = sum(p["status"] == "running" for p in projects)
    return render_template("index.html", projects=projects, running=running)

@bp.post("/create")
def create():
    if not logged_in(): return redirect(url_for("main.login"))
    name = safe_name(request.form.get("name"))
    if not name:
        flash("Project name must use letters, numbers, _ or - (max 40).")
    else:
        p = user_root() / name
        p.mkdir(exist_ok=True)
        main = p / "main.py"
        if not main.exists():
            main.write_text('print("Hello from KING WAHID HOSTING!")\\n', encoding="utf-8")
        flash(f"Project {name} created.")
    return redirect(url_for("main.index"))

@bp.post("/upload")
def upload():
    if not logged_in(): return redirect(url_for("main.login"))
    name = safe_name(request.form.get("name"))
    f = request.files.get("file")
    if not name or not f or not f.filename:
        flash("Project name and file are required.")
        return redirect(url_for("main.index"))
    filename = secure_filename(f.filename)
    if not filename.lower().endswith((".py", ".zip")):
        flash("Only .py and .zip files are accepted.")
        return redirect(url_for("main.index"))
    dest = user_root() / name
    if dest.exists():
        flash("Project already exists. Choose another name.")
        return redirect(url_for("main.index"))
    dest.mkdir()
    try:
        if filename.lower().endswith(".py"):
            f.save(dest / filename)
            if filename != "main.py":
                shutil.copy2(dest / filename, dest / "main.py")
        else:
            tmp = dest / "upload.zip"
            f.save(tmp)
            with zipfile.ZipFile(tmp) as z:
                members = z.infolist()
                if len(members) > 200:
                    raise ValueError("Too many files in ZIP.")
                total = sum(x.file_size for x in members)
                if total > 30 * 1024 * 1024:
                    raise ValueError("Uncompressed ZIP is too large (30 MB max).")
                for m in members:
                    path = PurePosixPath(m.filename)
                    if path.is_absolute() or ".." in path.parts:
                        raise ValueError("Unsafe ZIP path.")
                    if m.is_dir():
                        continue
                    target = (dest / Path(*path.parts)).resolve()
                    if dest.resolve() not in target.parents:
                        raise ValueError("Unsafe ZIP path.")
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with z.open(m) as src, target.open("wb") as dst:
                        shutil.copyfileobj(src, dst)
            tmp.unlink(missing_ok=True)
            if not any(dest.glob("*.py")):
                raise ValueError("ZIP must contain at least one .py file.")
        flash(f"Uploaded project {name}.")
    except Exception as e:
        shutil.rmtree(dest, ignore_errors=True)
        flash(f"Upload rejected: {str(e)[:180]}")
    return redirect(url_for("main.index"))

@bp.post("/project/<name>/<action>")
def project_action(name, action):
    if not logged_in(): return redirect(url_for("main.login"))
    p = owned_project(name)
    if action == "start":
        ok, msg = start_project(session["uid"], name, p, current_app.config["RUNNER_IMAGE"])
    elif action == "stop":
        ok, msg = stop_project(session["uid"], name)
    elif action == "delete":
        stop_project(session["uid"], name)
        shutil.rmtree(p, ignore_errors=True)
        ok, msg = True, f"Deleted {name}."
    else:
        abort(404)
    flash(msg)
    return redirect(url_for("main.index"))

@bp.get("/logs/<name>")
def logs(name):
    if not logged_in(): return redirect(url_for("main.login"))
    owned_project(name)
    return render_template("logs.html", name=name, logs=project_logs(session["uid"], name))

@bp.get("/admin")
def admin():
    if not logged_in(): return redirect(url_for("main.login"))
    if session.get("role") != "admin": abort(403)
    users = get_db().execute("SELECT id,email,role,created_at FROM users ORDER BY id DESC").fetchall()
    return render_template("admin.html", users=users)
