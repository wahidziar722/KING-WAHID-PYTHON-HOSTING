# KING WAHID PYTHON HOSTING

A multi-user Flask dashboard for uploading and running Python projects in Docker containers.

## Features
- Email/password registration and login
- Per-user project directories
- Upload `.py` or `.zip` projects
- Create, run, stop, delete and view logs
- Admin role assigned to the email configured in `ADMIN_EMAIL`
- CSRF protection and password hashing
- Docker execution isolation: no network, 256 MB memory, 0.5 CPU, 64 process limit, read-only project mount, dropped Linux capabilities

## Important limitations
This is a starter MVP, not a fully audited public hosting service. Do not expose it to the public internet until you have:
- A VPS with Docker configured securely
- HTTPS/reverse proxy and firewall
- A strong `SECRET_KEY` and non-default admin email
- Server-side rate limits, email verification, quotas and abuse monitoring
- Docker daemon access restricted to this application; never mount the host Docker socket into user containers
- Regular security updates, backups and log rotation

The runner has network access disabled intentionally. Uploaded projects requiring internet APIs will not work until you design a controlled egress policy. `requirements.txt` is not installed automatically in this MVP; add vetted dependency builds before enabling that feature.

## Local setup (Linux VPS)
1. Install Python 3.12+ and Docker Engine.
2. In this folder, build the restricted runner image:
   `docker build -t wahid-python-runner:latest .`
3. Create a virtual environment and install dependencies:
   `python3 -m venv .venv && . .venv/bin/activate`
   `pip install -r requirements.txt`
4. Set environment variables:
   `export SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"`
   `export ADMIN_EMAIL="your-admin-email@example.com"`
5. Start:
   `gunicorn --workers 1 --bind 0.0.0.0:8080 run:app`

Use a reverse proxy such as Caddy or Nginx for HTTPS. Do not use Flask's development server in production.

## GitHub
Create a private GitHub repository first. Upload the extracted project files. Never commit `.env`, database files, user uploads, tokens or passwords.
